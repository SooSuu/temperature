from flask import Flask, render_template, request

import sqlite3

import Adafruit_DHT
import RPi.GPIO as GPIO
import time

app = Flask(__name__)
# mail = Mail(app)

# Retrieve data from database
def getData():
	conn=sqlite3.connect('../sensorsData.db')
	curs=conn.cursor()
	for row in curs.execute("SELECT * FROM DHT_data ORDER BY timestamp DESC LIMIT 1"):
		time = str(row[0])
		temp = row[1]
		hum = row[2]
	conn.close()
	return time, temp, hum

# main route 
@app.route("/") 
def index():	
	time, temp, hum = getData()
	templateData = {
		'time': time,
		'temp': temp,
		'hum': hum
	}
	return render_template('index.html', title='DHT Sensor Data', **templateData)

@app.route("/alarm")
def alarm():
    return render_template("alarm.html", title='Alarm')


@app.route("/graph")
def graph():
    return render_template("graph.html", title='Graph')

@app.route("/camera")
def camera():
    return render_template("camera.html", title='Camera')


@app.route("/info")
def info():
    return render_template("info.html", title='Info')

@app.route("/Exp_date")
def Exp_date():
    return render_template("Exp_date.html", title='Exp_date')

@app.route("/test")
def test():
    return render_template("test.html", title='Test')

if __name__ == "__main__":
   app.run(host='0.0.0.0', port=80, debug=False)