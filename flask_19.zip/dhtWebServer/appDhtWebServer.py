from flask import Flask, render_template, request, redirect, url_for, flash
import sqlite3 as sql

app = Flask(__name__)

# Retrieve data from database
def getData():
	conn=sql.connect('../sensorsData.db')
	curs=conn.cursor()
	for row in curs.execute("SELECT * FROM DHT_data ORDER BY timestamp DESC LIMIT 1"):
		time = str(row[0])
		temp = row[1]
		hum = row[2]
	conn.close()
	return time, temp, hum

# main route 
@app.route("/") 
def index():	
	time, temp, hum = getData()
	templateData = {
		'time': time,
		'temp': temp,
		'hum': hum
	}
	return render_template('index.html', title = 'DHT Sensor Data', **templateData)

# vaccine page
@app.route("/vaccine")
def vaccine():
    return render_template("vaccine.html", title = 'Vaccine')

@app.route('/enternew')
def new_vaccine() :
    return render_template('db_addvaccine.html', title = 'Add Vaccine')

@app.route('/addrec', methods = ['POST','GET'])
def addrec() :
    if request.method == 'POST' :

        name = request.form['nm']
        exp_date = request.form['exp_d']

        if name == "" or exp_date == "":                    # 12.19 공백값 입력시 flash로 입력값 뜨고 다시 값 이력하게 함.
            flash("입력되지 않은 값이 있습니다!")
            return render_template("db_addvaccine.html")

        else:

            try :
                
                with sql.connect('../sensorsData.db') as con :
                    cur = con.cursor()
                    cur.execute('INSERT INTO VACCINE (NAME, EXPIRATION_DATE) VALUES (?,?)', (name, exp_date))
                    con.commit()
                    msg = 'Record successfully added'
            except :
                con.rollback()
                msg = 'Error in insert operation'
            finally :
                return render_template('db_result.html', title = 'Add Result Massage', msg = msg)
                con.close()
    return ''
# def addrec() :
#     if request.method == 'POST' :
#         try :
#             name = request.form['nm']
#             exp_date = request.form['exp_d']

#             with sql.connect('../sensorsData.db') as con :
#                 cur = con.cursor()

#                 cur.execute('INSERT INTO VACCINE (NAME, EXPIRATION_DATE) VALUES (?,?)', (name, exp_date))
#                 con.commit()
#                 msg = 'Record successfully added'
#         except :
#             con.rollback()
#             msg = 'Error in insert operation'
#         finally :
#             return render_template('db_result.html', title = 'Add Result Massage', msg = msg)
#             con.close()
#     return ''

@app.route('/list')
def list() :
    con = sql.connect('../sensorsData.db')

    cur = con.cursor()
    cur.execute('SELECT * FROM VACCINE')
    rows = cur.fetchall()
    con.close()
    return render_template('db_list.html', title = 'List', rows = rows)

# alarm page
@app.route("/alarm")
def alarm():
    return render_template("alarm.html", title = 'Alarm')

@app.route('/enternew_alarm')
def new_temp_r() :
    return render_template('db_addtempr.html', title = "Add Temperature's Regution")

@app.route('/addtempr', methods = ['POST','GET'])
def addtempr() :
    if request.method == 'POST' :
        max = request.form['Max']
        min = request.form['Min']

        try :
            with sql.connect('../sensorsData.db') as con :
                cur = con.cursor()
                cur.execute('INSERT INTO TEMP_R (MAX, MIN) VALUES (?,?)', (max, min))
                con.commit()
                msg = 'Record successfully added'
        except :
            con.rollback()
            msg = 'Error in insert operation'
        finally :
            return render_template('db_alarm_result.html', title = 'Add Result Massage', msg = msg)
            con.close()
    return ''

@app.route('/list_tempr')
def list_tempr() :
    con = sql.connect('../sensorsData.db')
    cur = con.cursor()
    for row in cur.execute('SELECT * FROM TEMP_R ORDER BY DATETIME DESC LIMIT 1'):
        now_max = row[2]
        now_min = row[3]  
    con.close()
    return render_template('db_list_tempr.html', now_max, now_min, title = "Temperature's Reguration Value List")
    # rows = cur.fetchall()
    # return render_template('db_list_tempr.html', title = "Temperature's Reguration Value List", rows = rows)

# @app.route("/temp_result",methods = ['POST', 'GET'])
# def result():
# 	if request.method == 'POST':
# 		result = request.form
# 		MAX = int(result['MAX'])
# 		MIN = int(result['MIN'])
# 		time, temp, hum = getData()
# 		templateData = {
# 			'time': time,
# 			'temp': temp,
# 			'hum': hum,
# 			'MAX': MAX,
# 			'MIN': MIN,
# 			}

# 		return render_template("temp_result.html", title = 'Temperation Alarm Result' ,**templateData)

# graph page
@app.route("/graph")
def graph():
    return render_template("graph.html", title = 'Graph')

# camera page
@app.route("/camera")
def camera():
    return render_template("camera.html", title = 'Title')

# info page
@app.route("/info")
def info():
    return render_template("info.html", title = 'Info')

# app run
if __name__ == "__main__":
   app.run(host='0.0.0.0', port=80, debug=False)