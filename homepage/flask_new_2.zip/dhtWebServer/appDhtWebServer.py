from flask import Flask, render_template, request, redirect, url_for, flash, session, Response
from datetime import datetime

import sqlite3 as sql
# from camera_pi import Camera


app = Flask(__name__)

# Retrieve data from database
def getData():
    con=sql.connect('../sensorsData.db')
    curs=con.cursor()

    for row in curs.execute("SELECT * FROM DHT_data ORDER BY timestamp DESC LIMIT 1"):
        time = str(row[0])
        temp = row[1]
        hum = row[2]
    con.close()
    return time, temp, hum

def gen(camera):
    """Video streaming generator function."""
    while True:
        frame = camera.get_frame()
        yield (b'--frame\r\n'
               b'Content-Type: image/jpeg\r\n\r\n' + frame + b'\r\n')	

def get_temperature_setting_value():
    con=sql.connect('../sensorsData.db')
    curs=con.cursor()

    for row in curs.execute('SELECT * FROM TEMP_R ORDER BY CREATED_AT DESC LIMIT 1'):
        now_max = row[2]
        now_min = row[3]
    con.close()
    return now_max, now_min

# main route
@app.route("/")
def index():
	time, temp, hum = getData()
	templateData = {
		'time': time,
		'temp': temp,
		'hum': hum
	}
	return render_template('index.html', title = 'DHT Sensor Data', **templateData)


# vaccine page

@app.route("/db_addvaccine")
def new_vaccine() :
    return render_template('db_addvaccine.html', title = 'Add Vaccine')

# vaccine gragh
def vaccine_graph():
    result=[]
    named=[]
    postshelf=[]
    postnamed=[]
    time = datetime.now()
    time1 = time.strftime('%Y-%m-%d %H:%M:%S')
    time2 = datetime.strptime(time,'%Y-%m-%d %H:%M:%S')
    ymax=time+relativedelta(days=30)
    con=sql.connect('../sensorData.db')
    curs=con.cursor()
    curs.execute("SELECT * from VACCINE")
    for row in curs.fetchall():
        date_time_str=row[2]
        date_time_obj=datetime.strptime(date_time_str,'%Y-%m-%d %H:%M:%S')
        if date_time_obj>time2:
            result.append(date_time_obj)
            named.append(row[1])
        else:
            postnamed.append(date_time_obj)
            postshelf.append(row[1])
    mpl.rcParams['axes.unicode_minus'] = False
    plt.rcParams["font.family"]='NanumGothic'
    plt.axis([0,30,time,ma])
    plt.title("백신")
    plt.xlabel('Vaccine name')
    plt.ylabel('days')
    plt.bar(named,result,label='유통기한')
    plt.legend()

    # 그래프 저장 경로
    plt.savefig('/home/pi/21211/dhtWebServer/templates/vaccine.png')
    plt.show()

@app.route('/addrec', methods = ['POST','GET'])
def addrec() :
    if request.method == 'POST' :
        try :
            name = request.form['nm']
            exp_date = request.form['exp_d']

            with sql.connect('../sensorsData.db') as con :
                cur = con.cursor()
                cur.execute('INSERT INTO VACCINE (NAME, EXPIRATION_DATE) VALUES (?,?)', (name, exp_date))
                con.commit()
                msg = 'Vaccine added successfully'
        except :
            con.rollback()
            msg = 'Error in insert operation'
        finally :
            return render_template('db_result.html', title = 'Add Result Massage', msg = msg)
            con.close()
    return ''
# def addrec() :
#     if request.method == 'POST' :
#         try :
#             name = request.form['nm']
#             exp_date = request.form['exp_d']

#             with sql.connect('../sensorsData.db') as con :
#                 cur = con.cursor()

#                 cur.execute('INSERT INTO VACCINE (NAME, EXPIRATION_DATE) VALUES (?,?)', (name, exp_date))
#                 con.commit()
#                 msg = 'Record successfully added'
#         except :
#             con.rollback()
#             msg = 'Error in insert operation'
#         finally :
#             return render_template('db_result.html', title = 'Add Result Massage', msg = msg)
#             con.close()
#     return ''

@app.route('/db_list')
def list() :
    con = sql.connect('../sensorsData.db')

    cur = con.cursor()
    cur.execute('SELECT * FROM VACCINE')
    rows = cur.fetchall()
    con.close()
    return render_template('db_list.html', title = 'List', rows = rows)

# alarm page
@app.route("/db_addalarm")
def set_alarm():
    return render_template("db_addalarm.html", title = 'Setting Temperature Alarm')

@app.route('/db_alarm_result', methods = ['POST','GET'])
def addtempr() :
    if request.method == 'POST' :
        try :
            max = request.form['Max']
            min = request.form['Min']
            with sql.connect('../sensorsData.db') as con :
                cur = con.cursor()
                cur.execute('INSERT INTO TEMP_R (MAX, MIN) VALUES (?,?)', (max, min))
                con.commit()
                msg = 'Alarm added successfully'
        except :
            con.rollback()
            msg = 'Error in insert operation'
        finally :
            return render_template('db_alarm_result.html', title = 'Add Result Massage', msg = msg)
           
    return ''

# @app.route('/list_tempr')
# def list_tempr() :
#     con = sql.connect('../sensorsData.db')
#     cur = con.cursor()
#     cur.execute('SELECT * FROM TEMP_R')
#     rows = cur.fetchall()
#     con.close()
#     return render_template('db_list_tempr.html', title = "Temperature's Reguration Value List", rows = rows)

@app.route("/db_list_tempr")
def re_alrm():
	now_max, now_min = get_temperature_setting_value()
	templateData = {
		'현재 최대 온도': now_max,
		'현재 최소 온도': now_min,
	}
	return render_template('db_list_tempr.html', rowo=templateData)

# login
@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        name = request.form['username']
        password = request.form['password']
        try:
            if name in userinfo:
                if userinfo[name] == password:
                    session['logged_in'] = True
                    return redirect(url_for('loggedin.html'))
                else:
                    return '비밀번호를 다시 확인해주세요!'
            return 'ID가 존재하지 않습니다.'
        except:
            return 'ID가 존재하지 않습니다!'
    else:
        return render_template('login.html')

@app.route('/register', methods=['GET', 'POST'])
def regist():
    if request.method == 'POST':
        userinfo[request.form['username']] = request.form['password']
        return redirect(url_for('login'))
    else:
        return render_template('register.html')

@app.route("/logout")
def logout():
    session['logged_in'] = False
    return render_template('index.html')

# CCTV
@app.route('/video_feed')
def video_feed():
    """Video streaming route. Put this in the src attribute of an img tag."""
    return Response(gen(Camera()), mimetype='multipart/x-mixed-replace; boundary=frame')

# app run
if __name__ == "__main__":
   app.run(host='0.0.0.0', port=80, debug=False)
