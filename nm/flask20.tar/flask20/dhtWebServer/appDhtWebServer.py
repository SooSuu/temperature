from flask import Flask, render_template, request, redirect, url_for, flash
from datetime import datetime

import sqlite3 as sql

# from apscheduler.schedulers.background import BackgroundScheduler
# from webapp.models.main import db 
# from webapp.controllers.main import main_blueprint

app = Flask(__name__)

# Retrieve data from database
def getData():
    con=sql.connect('../sensorsData.db')
    curs=con.cursor()

    for row in curs.execute("SELECT * FROM DHT_data ORDER BY timestamp DESC LIMIT 1"):
        time = str(row[0])
        temp = row[1]
        hum = row[2]
    con.close()
    return time, temp, hum

def get_temperature_setting_value():
    con=sql.connect('../sensorsData.db')
    curs=con.cursor()
    
    for row in curs.execute('SELECT * FROM TEMP_R ORDER BY CREATED_AT DESC LIMIT 1'):
        now_max = row[2]
        now_min = row[3]  
    con.close()
    return now_max, now_min

# scheduler
# import BackgroundScheduler
 
def create_app(object_name):
    app = Flask(__name__)
    app.config.from_object(object_name)
    db.init_app(app)
    app.register_blueprint(main_blueprint)
    # init BackgroundScheduler job
    scheduler = BackgroundScheduler()
    # in your case you could change seconds to hours
    scheduler.add_job(get_temperature_setting_value, trigger='interval', seconds=3)
    scheduler.start()

    try:
        # To keep the main thread alive
        return app
    except:
        # shutdown if app occurs except 
        scheduler.shutdown()
        
# main route 
@app.route("/") 
def index():	
	time, temp, hum = getData()
	templateData = {
		'time': time,
		'temp': temp,
		'hum': hum
	}
	return render_template('index.html', title = 'DHT Sensor Data', **templateData)

# vaccine page
@app.route("/vaccine")
def vaccine():
    return render_template("vaccine.html", title = 'Vaccine')

@app.route('/enternew')
def new_vaccine() :
    return render_template('db_addvaccine.html', title = 'Add Vaccine')

@app.route('/addrec', methods = ['POST','GET'])
def addrec() :
    if request.method == 'POST' :
        try :
            name = request.form['nm']
            exp_date = request.form['exp_d']
            
            with sql.connect('../sensorsData.db') as con :
                cur = con.cursor()
                cur.execute('INSERT INTO VACCINE (NAME, EXPIRATION_DATE) VALUES (?,?)', (name, exp_date))
                con.commit()
                msg = 'Record successfully added'
        except :
            con.rollback()
            msg = 'Error in insert operation'
        finally :
            return render_template('db_result.html', title = 'Add Result Massage', msg = msg)
            con.close()
    return ''
# def addrec() :
#     if request.method == 'POST' :
#         try :
#             name = request.form['nm']
#             exp_date = request.form['exp_d']

#             with sql.connect('../sensorsData.db') as con :
#                 cur = con.cursor()

#                 cur.execute('INSERT INTO VACCINE (NAME, EXPIRATION_DATE) VALUES (?,?)', (name, exp_date))
#                 con.commit()
#                 msg = 'Record successfully added'
#         except :
#             con.rollback()
#             msg = 'Error in insert operation'
#         finally :
#             return render_template('db_result.html', title = 'Add Result Massage', msg = msg)
#             con.close()
#     return ''

@app.route('/list')
def list() :
    con = sql.connect('../sensorsData.db')

    cur = con.cursor()
    cur.execute('SELECT * FROM VACCINE')
    rows = cur.fetchall()
    con.close()
    return render_template('db_list.html', title = 'List', rows = rows)

# alarm page
@app.route("/alarm")
def alarm():
    return render_template("alarm.html", title = 'Alarm')

@app.route("/enter_new_alarm")
def set_alarm():
    return render_template("db_addalarm.html", title = 'Setting Temperature Alarm')

@app.route('/addtempr', methods = ['POST','GET'])
def addtempr() :
    if request.method == 'POST' :
        try :
            max = request.form['Max']
            min = request.form['Min']
            with sql.connect('../sensorsData.db') as con :
                cur = con.cursor()
                cur.execute('INSERT INTO TEMP_R (MAX, MIN) VALUES (?,?)', (max, min))
                con.commit()
                msg = 'Record successfully added'
        except :
            con.rollback()
            msg = 'Error in insert operation'
        finally :
            return render_template('db_alarm_result.html', title = 'Add Result Massage', msg = msg)
            con.close()
    return ''

# @app.route('/list_tempr')
# def list_tempr() :
#     con = sql.connect('../sensorsData.db')
#     cur = con.cursor()
#     cur.execute('SELECT * FROM TEMP_R')
#     rows = cur.fetchall()
#     con.close()
#     return render_template('db_list_tempr.html', title = "Temperature's Reguration Value List", rows = rows)

@app.route("/list_tempr")
def re_alrm():
	now_max, now_min = get_temperature_setting_value()
	templateData = {
		'현재 최대 온도': now_max,
		'현재 최소 온도': now_min,
	}
	return render_template('db_list_tempr.html', rowo=templateData)

# graph page
@app.route("/graph")
def graph():
    return render_template("graph.html", title = 'Graph')

# camera page
@app.route("/camera")
def camera():
    return render_template("camera.html", title = 'Title')

# info page
@app.route("/info")
def info():
    return render_template("info.html", title = 'Info')

# app run
if __name__ == "__main__":
   app.run(host='0.0.0.0', port=80, debug=False)
