import os
import smtplib
 
from email.utils import formataddr
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
 
from_addr = formataddr(('온습도 관리 위원회', 'rkfaorl1480@gmail.com'))
to_addr = formataddr(('습온도 관리 위원회', 'rkfaorl1480@gmail.com'))
 
session = None

def mail():
    try:
        # SMTP 세션 생성
        session = smtplib.SMTP('smtp.gmail.com', 587)
        session.set_debuglevel(True)

        # SMTP 계정 인증 설정회
        session.ehlo()
        session.starttls()
        session.login('rkfaorl1480@gmail.com', 'gaeq ocqv tfvr gqmx')

        # 메일 콘텐츠 설정
        message = MIMEMultipart("alternative")

        # 메일 송/수신 옵션 설정
        message.set_charset('utf-8')
        message['From'] = from_addr
        message['To'] = to_addr
        message['Subject'] = '비상비상'

        # 메일 콘텐츠 - 내용
        body = '''
        <h2>족됨</h2>
        <h4>온도 떨어진다~~~~</h4>
        '''
        bodyPart = MIMEText(body, 'html', 'utf-8')
        message.attach( bodyPart )

        # 메일 발송
        session.sendmail(from_addr, to_addr, message.as_string())

        print( 'Successfully sent the mail!!!' )
    except Exception as e:
        print( e )
    finally:
        if session is not None:
            session.quit()